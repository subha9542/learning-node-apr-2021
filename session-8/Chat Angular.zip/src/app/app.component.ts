import { Component } from '@angular/core';
import { ChatService } from './services/chat.service';


@Component({
  selector: 'tacochat-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'tacochat';

  constructor(private chat : ChatService) {
      this.chat.recieve()
  }
}
