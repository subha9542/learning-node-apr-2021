import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'changecase'
})
export class ChangecasePipe implements PipeTransform {

  transform(value: string, ...args: any[]): unknown {
    console.log(args)

    if(args[0] === 'upper'){
      return value.toUpperCase();
    }
    else if (args[0] === 'lower'){
      return value.toLowerCase();
    }
    return value;
  }

}

// === and ==
// === value and type
// == value
// '1' == 1 true
// '1' === 1 false
