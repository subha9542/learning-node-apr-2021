import { ChangecasePipe } from './changecase.pipe';

describe('ChangecasePipe', () => {
  it('create an instance', () => {
    const pipe = new ChangecasePipe();
    expect(pipe).toBeTruthy();
  });
});
