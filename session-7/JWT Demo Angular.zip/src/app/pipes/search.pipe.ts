import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {

  transform(value: any[], ...args: any[]): unknown {

    const minimumPrice = args && args[0] || 20000


    return value.filter((item) => {
      return item.fee < minimumPrice
    });
  }

}
