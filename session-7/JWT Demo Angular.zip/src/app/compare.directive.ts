import { Directive, Input } from '@angular/core';
import { FormGroup, NG_VALIDATORS, Validator } from '@angular/forms';
import { CompareValidator } from './validators/compare';

@Directive({
  selector: '[tacoCompare]',
  providers: [{
    provide: NG_VALIDATORS,
    useExisting: CompareDirective,
    multi: true
  }]
})
export class CompareDirective implements Validator {
  @Input("tacoCompare") tacoCompare: string[] = [];

  constructor() { }

  validate(group: FormGroup) {

    const validatorFn = CompareValidator(this.tacoCompare[0], this.tacoCompare[1])
    return validatorFn(group)
  }

}
