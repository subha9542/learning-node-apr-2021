import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from "@angular/router"
import { ProductsService } from '../services/products.service';

@Component({
  selector: 'taco-order-detail-page',
  templateUrl: './order-detail-page.component.html',
  styleUrls: ['./order-detail-page.component.scss']
})
export class OrderDetailPageComponent implements OnInit, OnDestroy {

  orderDetails = {
    description: ""
  };
  orderId = null

  constructor(private activateRoute: ActivatedRoute, private products: ProductsService) {

  }

  ngOnInit(): void {
    console.log("init");
    this.activateRoute.params.subscribe((params) => {
      this.orderId = params.orderid;
      this.orderDetails = this.products.getOrder(this.orderId)

    

    })
  }

  ngOnDestroy() {
    console.log("destroy")
  }

}
