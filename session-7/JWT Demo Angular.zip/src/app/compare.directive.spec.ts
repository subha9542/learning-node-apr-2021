import { CompareDirective } from './compare.directive';

describe('CompareDirective', () => {
  it('should create an instance', () => {
    const directive = new CompareDirective();
    expect(directive).toBeTruthy();
  });
});
