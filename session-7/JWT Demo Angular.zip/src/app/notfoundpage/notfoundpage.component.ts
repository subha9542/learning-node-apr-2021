import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'taco-notfoundpage',
  templateUrl: './notfoundpage.component.html',
  styleUrls: ['./notfoundpage.component.scss']
})
export class NotfoundpageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
