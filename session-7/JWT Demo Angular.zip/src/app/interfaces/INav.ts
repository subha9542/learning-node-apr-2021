export interface INav {
    name : string
    url : string
}