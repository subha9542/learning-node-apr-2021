export interface IEmployee {
    employeeId : string
    firstName : string
    lastName : string
    salary : number
    dept : string
}