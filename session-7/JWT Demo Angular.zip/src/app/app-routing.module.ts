import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { MenupageComponent } from './menupage/menupage.component';
import { NotfoundpageComponent } from './notfoundpage/notfoundpage.component';
import { OrderDetailPageComponent } from './order-detail-page/order-detail-page.component';
import { AboutUsComponent } from './pages/about-us/about-us.component';
import { HomepageComponent } from './pages/homepage/homepage.component';
import { OrdersComponent } from './pages/orders/orders.component';

const routes: Routes = [
  {
    path: "", component: HomepageComponent
  },
  {
    path: "about-us", component: AboutUsComponent
  },
  {
    path: "orders", component: OrdersComponent, /*canActivate : [AuthGuard]*/
  }, 
  {
    path: "orders/:orderid", component: OrderDetailPageComponent
  },
  // orders/1
  // orders/sometext
  // orders/1/sometext
  // orders/sometext/someusername,
  {
    path: "products", redirectTo: "/orders"
  },

  {
    path: "menu", component: MenupageComponent
  },
  {
    path: "specials", redirectTo: "/menu"
  },
  {
    path: "**", component: NotfoundpageComponent
  },
];

// /Samsung-Galaxy-M12-Storage-Processor/dp/B08XGDN3TZ/ref=lp_21505777031_1_1

// /Samsung-Galaxy-Mirage-128GB-Storage/dp/B07DJCJBB3/ref=lp_21505777031_1_5

// example.com > ""
// example.com/about-us > "about-us"
// example.com/orders > "orders"

@NgModule({
  // imports: [RouterModule.forRoot(routes, { useHash : true })],
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
