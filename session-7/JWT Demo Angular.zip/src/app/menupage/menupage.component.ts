import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'taco-menupage',
  templateUrl: './menupage.component.html',
  styleUrls: ['./menupage.component.scss']
})
export class MenupageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
