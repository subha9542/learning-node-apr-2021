import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from "@angular/router";

import { trigger, state, style, animate, transition, query, stagger } from "@angular/animations"

@Component({
  selector: 'taco-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.scss'],
  animations: [
    trigger("listingAnimation", [
      transition(":enter", [
        query("li", [
          style({ color: "#ff0000", opacity: 0 }),
          stagger(-100, [
            animate("500ms",
              style({ color: "#00ff00", opacity: 1 })
            )
          ])
        ]),

      ])
    ]),
    trigger("buttonAnimation", [
      state("show", style({
        opacity: 1,
        backgroundColor: "#ff0000"
      })),
      state("hide", style({
        opacity: 0,
        backgroundColor: "#00ff00"
      })),
      transition("show => hide", [
        animate("2s")
      ]),
      transition("hide => show", [
        animate("0.5s")
      ])

    ])
  ]
})
export class HomepageComponent implements OnInit, OnDestroy {

  showButton = true;

  constructor(private router: Router) { }


  ngOnInit(): void {
    console.log("init homepage")
  }

  ngOnDestroy() {
    console.log("destroy homepage")
  }

  gotoMenu() {
    this.router.navigate(["/menu"])
  }

  animateButton() {
    this.showButton = !this.showButton
  }

  // homepage/param1/param2
  // this.router.navigate(["/homepage", "/param1", "/param2" ])

  // homepage/param1/param2
  // this.router.navigateByUrl("/homepage/param1/param2")

}
