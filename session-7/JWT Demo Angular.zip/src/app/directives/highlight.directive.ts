import { Directive, ElementRef, HostListener, Input } from '@angular/core';

// [tacoHighlight]  attribute
// .tacoHighlight   class
// #tacoHighlight   id
// tacoHighlight    custom element

@Directive({
  selector: '[tacoHighlight]'
})
export class HighlightDirective {

    el : ElementRef

    @Input() tacoHighlight : string = "red"

    @HostListener("mouseover") over(){
        this.el.nativeElement.style.color = this.tacoHighlight;
    }

    @HostListener("mouseout") handlerForOut(){
      this.el.nativeElement.style.color = ""
  }

  constructor(el : ElementRef) {
      this.el = el;
  }

}
