import { Component, OnInit } from '@angular/core';

import { HttpClient } from "@angular/common/http"

@Component({
  selector: 'taco-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.scss']
})
export class LoginFormComponent implements OnInit {

  form = {
    username: "",
    password: "",
  }

  name = "abc";
  constructor(private http: HttpClient) {

  }

  ngOnInit(): void {
  }

  changeName() {
    this.name = "xyz"
  }



  login(loginForm) {
    alert(JSON.stringify(loginForm.value))
    this.http.post("http://localhost:3600/login", { email: this.form.username, password: this.form.password })
      .subscribe((response: any) => {
        window.localStorage.setItem("access-token", response.accessToken);
      })


  }


}
