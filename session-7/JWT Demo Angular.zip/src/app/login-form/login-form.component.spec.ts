import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from "@angular/forms"
import { By } from '@angular/platform-browser';

import { LoginFormComponent } from './login-form.component';

describe('LoginFormComponent', () => {
  let component: LoginFormComponent;
  let fixture: ComponentFixture<LoginFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [LoginFormComponent],
      imports : [FormsModule]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have property name as "xyz"', () => {
    component.changeName()
    expect(component.name).toBe("xyz")
  });

  it('should have property name as "abc"', () => {
    expect(component.name).toBe("abc")
  });

  it('should change name in button cliick', () => {
      fixture.detectChanges();
      const debugElement = fixture.debugElement;
      const button = debugElement.query(By.css(".change-name-button")).nativeElement
      const text = debugElement.query(By.css("p.username"));

      expect(text).toBeTruthy();

      const textNativeElement = text.nativeElement;
      button.click();
      fixture.detectChanges();
      expect(component.name).toBe("xyz")
      expect(textNativeElement.innerText).toBe("xyz")

  });

 



});