import { Injectable } from '@angular/core';

import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  constructor(private http: HttpClient) { }

  // products : any[] = [
  //   { id : "vanilla cake", price : 15.00, size : "large" }
  // ]


  orders = [
    {
      id: "1",
      description: "this is order 1"
    },
    {
      id: "2",
      description: "this is order 2"
    },
    {
      id: "3",
      description: "this is order 3"
    },
    {
      id: "4",
      description: "this is order 4"
    }
  ]

  getProducts() {
    return this.http.get("http://localhost:3000/products") // Observable is created
  }

  getOrder(id) {
    return this.orders.find((order) => {
      return order.id === id
    })
  }

}
