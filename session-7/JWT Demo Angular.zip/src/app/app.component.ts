import { Component } from '@angular/core';
import { from, interval, of, throwError } from 'rxjs';
import { map, find, take, filter } from "rxjs/operators";

import { HttpClient } from "@angular/common/http"

@Component({
  selector: 'taco-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {


  constructor(private http: HttpClient) {
    this.http.get("http://localhost:3600/whoami").subscribe((response) => {
      console.log(response)
    })
  }

  username = "";
  name = "Tacoshop";

  showMesssage = false;
  showElseContent = false;

  textSize = 12;

  price = 0;

  courses = [
    { name: "AWS", fee: 18500.50, startDate: "2021-03-25T14:12:20.998Z", topics: ["cloud", "ec2", "lambda"] },
    { name: "NodeJS", fee: 16500000000.99, startDate: "2021-03-28T14:12:20.998Z", topics: ["js", "fs", "http"] },
    { name: "Azure", fee: 25000.36, startDate: "2021-03-31T14:12:20.998Z", topics: ["function", "blob", "docker"] },
    { name: "PHP", fee: 27500.34545, startDate: "2021-03-27T14:12:20.998Z", topics: ["mysql"] }
  ]

  addClass = true;

  switchValue = ""

  handlerForSendMessage(event) {
    console.log("header component sent a message.", event);
  }
}


// of("").subscribe((data) => {
//   console.log(data);
// })

// from(["1", "2", "3"]).subscribe((data) => {
//   console.log(data);
// })

// const error = throwError("Error")
// error.subscribe(() => { }, error => { console.log(error) }, () => { })

// const timer = interval(5000)

// timer.subscribe(() => {
//   console.log("hello world");
// })

// from([1, 2, 3])
//   .pipe(map((item: any) => { console.log(item); return 10 * item }))
//   .subscribe((data) => {
//     console.log("Map and of");
//     console.log(data);
//   })

// from([{ name: "praveen", salary: 100 }, { name: "abc", salary: 50 }, { name: "def", salary: 80 }])
//   .pipe(find((item: any) => {
//     return item.salary >= 80
//   }))
//   .subscribe((data) => {
//     console.log("find");
//     console.log(data);
//   })

//   from([{ name: "praveen", salary: 100 }, { name: "abc", salary: 50 }, { name: "def", salary: 80 }])
//   .pipe(filter((item: any) => {
//     return item.salary >= 80
//   }))
//   .subscribe((data) => {
//     console.log("filter");
//     console.log(data);
//   })


// const timer1 = interval(1000)


// timer1.pipe(take(3)).subscribe(() => {
//   console.log("Take Method")
// })