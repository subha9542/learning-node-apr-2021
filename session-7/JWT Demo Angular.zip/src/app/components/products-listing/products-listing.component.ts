import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ProductsService } from "../../services/products.service"

@Component({
  selector: 'taco-products-listing',
  templateUrl: './products-listing.component.html',
  styleUrls: ['./products-listing.component.scss']
})
export class ProductsListingComponent implements OnInit {

  productsListing = [];

  // Products is local to constructor
  // constructor(products : ProductsService) {
     
  // }

  // Products is private to class can be used anywhere in class
  constructor(private products : ProductsService) {
     
  }

  ngOnInit(): void {
    
    const observableForProducts = this.products.getProducts()
    observableForProducts
    .subscribe((response : any)=>{
        this.productsListing = response;
    })

    // this.products.getProducts().subscribe((response : any)=>{
    //   this.productsListing = response;
    // })
  }

}
