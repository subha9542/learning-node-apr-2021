import { Component, OnInit } from '@angular/core';
import { IEmployee } from "../../interfaces/IEmployee"
@Component({
  selector: 'taco-data-grid',
  templateUrl: './data-grid.component.html',
  styleUrls: ['./data-grid.component.scss']
})
export class DataGridComponent implements OnInit {

  showEdit : boolean = false;

  employee: IEmployee = { 
    employeeId: "LKJGJHSGDJS",
    firstName : "ABC",
    lastName : "DEF",
    salary : 10566454654654654,
    dept : "Development"
  }

  constructor() { }

  ngOnInit(): void {
  }

  EditEmp(){
      this.showEdit = true;
  }

  UpdateEmp(){
    this.showEdit = false;
  }

}
