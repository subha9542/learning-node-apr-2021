import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from "@angular/forms"
import { UserService } from 'src/app/services/user.service';
import { CompareValidator } from 'src/app/validators/compare';

@Component({
  selector: 'taco-register-form',
  templateUrl: './register-form.component.html',
  styleUrls: ['./register-form.component.scss']
})
export class RegisterFormComponent implements OnInit {

  registerForm = new FormGroup({
    username: new FormControl("", [Validators.required]),
    password: new FormControl("", [Validators.required, Validators.minLength(8), Validators.maxLength(64)]),
    confirmPassword: new FormControl(""),
    email: new FormControl("", [Validators.required, Validators.email]),
    address: new FormControl(""),
    confirm: new FormControl(false, [Validators.requiredTrue])
  }, { validators: [CompareValidator("password", "confirmPassword")] })

  // Validators.pattern("^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$")

  get username() {
    return this.registerForm.get("username")
  }

  get password() {
    return this.registerForm.get("password")
  }

  get confirmPassword() {
    return this.registerForm.get("confirmPassword")
  }

  get email() {
    return this.registerForm.get("email")
  }

  get address() {
    return this.registerForm.get("address")
  }
  get confirm() {
    return this.registerForm.get("confirm")
  }

  constructor(private userService: UserService) { }

  ngOnInit(): void {
  }

  register() {
    console.log(this.registerForm)
    this.userService.register(this.registerForm.value).subscribe((response) => {
      console.log(response);
    })
  }
}
