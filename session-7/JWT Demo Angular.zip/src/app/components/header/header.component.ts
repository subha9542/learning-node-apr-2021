import { Component, Input, OnInit, EventEmitter, Output } from '@angular/core';
import { INav } from "../../interfaces/INav"

@Component({
  selector: 'taco-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  @Input() storename;

  @Output() sendmessage : EventEmitter<any> = new EventEmitter();

  currentHour = 0;

  navlinks : INav[] = [
    { name : "Home", url : "/" },
    { name : "About", url : "/about-us" },
    { name : "Menu", url : "/menu" },
    { name : "Specials", url : "/specials" },
    { name : "Events", url : "/events" },
    { name : "Chefs", url : "/chefs" },
    { name : "Gallery", url : "/gallery" },
    { name : "Contact", url : "/contact" }
  ];

  constructor() { }



  ngOnInit(): void {
      this.currentHour = new Date().getHours();
  }

  handleClickEvent(event){
    alert("You clicked a link.");
    console.log(event);
  }

  navLinkClick(item){
      console.log("navlink clicked.", item);
      this.sendmessage.emit(item)
  }

}
