import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http"

import { BrowserAnimationsModule } from "@angular/platform-browser/animations"

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomepageComponent } from './pages/homepage/homepage.component';
import { AboutUsComponent } from './pages/about-us/about-us.component';
import { OrdersComponent } from './pages/orders/orders.component';
import { HeaderComponent } from './components/header/header.component';
import { TopbarComponent } from './components/topbar/topbar.component';
import { HeroComponent } from './components/hero/hero.component';
import { DataGridComponent } from './components/data-grid/data-grid.component';
import { HighlightDirective } from './directives/highlight.directive';
import { ChangecasePipe } from './pipes/changecase.pipe';
import { SearchPipe } from './pipes/search.pipe';
import { ProductsListingComponent } from './components/products-listing/products-listing.component';
import { NotfoundpageComponent } from './notfoundpage/notfoundpage.component';
import { MenupageComponent } from './menupage/menupage.component';
import { OrderDetailPageComponent } from './order-detail-page/order-detail-page.component';
import { LoginFormComponent } from './login-form/login-form.component';
import { RegisterFormComponent } from './components/register-form/register-form.component';
import { CompareDirective } from './compare.directive';
import { HttpInterceptorService } from './services/http-interceptor.service';


@NgModule({
  declarations: [
    AppComponent,
    HomepageComponent,
    AboutUsComponent,
    OrdersComponent,
    HeaderComponent,
    TopbarComponent,
    HeroComponent,
    DataGridComponent,
    HighlightDirective,
    ChangecasePipe,
    SearchPipe,
    ProductsListingComponent,
    NotfoundpageComponent,
    MenupageComponent,
    OrderDetailPageComponent,
    LoginFormComponent,
    RegisterFormComponent,
    CompareDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    BrowserAnimationsModule
  ],
  providers: [
      {
         provide : HTTP_INTERCEPTORS, useClass : HttpInterceptorService, multi : true
      }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
